import React from 'react';

// import DrawerToggleButton from '../../Components/SideDrawer/DrawerToggleButton'
import Logo from '../../Components/Logo/Logo';
import Membership from '../../Components/Membership/Membership';
import Search from '../../Components/Search/Search';
// import NavigationItems from '../../Components/Navigation/NavigationItems/NavigationItems';
import Navigation from '../../Components/Navigation/Navigation';
import SwipeableDrawer from '../../Components/SideDrawer/SwipeableDrawer';
import styles from './Toolbar.module.css'
// import ModeSwitch from "../Modes/Modes";
import { Link } from 'react-router-dom';
// import styled from "@emotion/styled";


// const Wrap = styled("header")`
//   background: ${props => props.theme.background};

// `;

const isLoggedIn = false;


const toolbar = props => (
    
   
    <header className={styles.gpa__toolbar}>
        <nav className={styles.gpa__toolbar_navigation}>
            <SwipeableDrawer className="gpa__mobile_drawer" />
            {/* <DrawerToggleButton click={props.drawerClickHandler}/> */}

            <div className={styles.gpa__toolbar_logo} ><Link to="/" > <Logo/></Link></div>
           
            <div className={styles.gpa__spacer}/>
            <div className={styles.gpa__toolbar_searchbar}>
                <Search/>
            </div>
            <div className={styles.gpa__toolbar_navigation_item}>
                <Navigation/>
            </div>
            {/* <Member /> */}
            {/* <ModeSwitch Icon={props.Icon } onClick={props.onClick}/> */}
            {props.children}
            
            <div className={isLoggedIn ? styles.gpa__toolbar_membership : null }>
                <Membership/>
            </div>

    
        </nav>
        </header>

);

export default toolbar;