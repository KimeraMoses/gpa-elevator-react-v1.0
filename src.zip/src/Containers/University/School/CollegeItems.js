export const CollegeItems = [
    {
       SchName: 'School of Engineering',
       deptName: ' Department of Computer and Electrical Engineering ',
       courseName: 'Bachelor Of Science in Computer Engineering',
       year: {
         sem: 'semester one',
         sem1: 'sem 2'
       }
    },
    {
        SchName: 'School of Engineering',
        deptName: ' Department of Computer and Electrical Engineering ',
        courseName: 'Bachelor Of Science in Computer Engineering'
     },
     {
        SchName: 'School of Engineering',
        deptName: ' Department of Computer and Electrical Engineering ',
        courseName: 'Bachelor Of Science in Computer Engineering'
     },
     {
        SchName: 'School of Engineering',
        deptName: ' Department of Computer and Electrical Engineering ',
        courseName: 'Bachelor Of Science in Computer Engineering'
     },
] 