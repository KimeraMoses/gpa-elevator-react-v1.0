import React from 'react';

import { CollegeItems } from './CollegeItems';

import './School.css';


const school =() =>{
    return(
       
        <div id="gpa__college_display_area">
            
            <div className="gpa__college_content_section gpa__main_content_area">
                <h2 className="gpa__college_title">CEDAT</h2>

            {CollegeItems.map((item, index) => {
                return(
                    <>

                <div className="gpa__college_school_title_container">     
                <h2 className="gpa__college_school_title"><b>{item.SchName } </b> </h2>   
                </div> 
                
                    
                <h3 className="gpa__school_dept_name">{ item.deptName }</h3>
                  
                    <div className="gpa__school_dept_course_wrapper">

                  
                    
                        <ul className="gpa__dept_course_ul"> 

                  
                            <li className="gpa__dept_course_li">
                                <input type="checkbox" className="gpa__course_checkbox" id="<?php echo $course_code;?>" autocomplete="off"/>
                                <label for="<?php echo $course_code;?>" className="gpa__course_label">

                                <h4 className ="gpa__dept_course_name"  data-toggle="gpa__arriar_hidden" data-target="#<?php echo $course_code;?>" aria-expanded="false"><b>{ item.courseName }</b></h4>
                                </label>                     


                                <ul className="gpa__arriar_hidden"  id="<?php echo $course_code;?>">

                                 {CollegeItems.map((item, index) => {
                                     return(
                                         <>
                                    <li className="gpa__academic_year"><b><i>YEAR ONE {item.sem }</i></b>


                            
                                        <ul>
                                        <li>
                                            <b className="gpa__semester_one_name"><i>SEMESTER ONE {item.sem1 }</i></b>
                                
                                            <ul>
                        
                                            <li className="gpa__semester_course_unit"><b><i><a  href="<?php echo $semester_one_course_unit_link;?>">CMP1102-Course Unit Name sem 1</a></i></b></li>

                                            </ul>

                                        </li>
                        
                                        <li>
                                            <b className="gpa__semester_one_name"><i>SEMESTER TWO</i></b>
                                        <ul>
                                            <li className="gpa__semester_course_unit">
                                                <b><i><a  href="<?php echo $semester_two_course_unit_link;?>">CMP1102-Course Unit Name</a></i></b>
                                            </li>
                                        </ul>

                                        </li>

                                        </ul>

                                    </li>
                                    </>
                                    )
                                })}
                            
                                </ul>


                            </li>
                       
                        </ul>


                    </div> 
                    </>
                    )
                })}
              
            </div>
        </div>

    );
}
export default school;