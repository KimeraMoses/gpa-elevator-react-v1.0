import React, { useState , useEffect } from "react";

import "./Containers/style.css";
import SwwipeableDrawer from './Components/SideDrawer/SwipeableDrawer';
import ToolBar from './Containers/Toolbar/Toolbar';
import { ReactComponent as LogoutIcon } from './Assests/icons/arrow-right.svg';
import { BrowserRouter, Route } from 'react-router-dom';

import Footer from './Components/Footer/Footer';
import Home from './Components/Pages/Home';
import College from './Components/Pages/College';

const App = (props) => {

  const [darkMode, setDarkMode] = useState(getInitialMode());
  useEffect(() => {
    localStorage.setItem("dark-mode", JSON.stringify(darkMode));
  }, [darkMode]);

  function getInitialMode() {
    const isReturningUser = "dark-mode" in localStorage;
    const savedMode = JSON.parse(localStorage.getItem("dark-mode"));
    const userPrefersDark = getPrefColorScheme();
    // if mode was saved --> dark / light
    if (isReturningUser) {
      return savedMode;
      // if preferred color scheme is dark --> dark
    } else if (userPrefersDark) {
      return true;
      // otherwise --> light
    } else {
      return false;
    }
    // return savedMode || false;
  }

  function getPrefColorScheme() {
    if (!window.matchMedia) return;

    return window.matchMedia("(prefers-color-scheme: dark-mode)").matches;
  }

  const Toggle = ()=>{
    return(
      <div className="toggle-container">
      {/* <span style={{ color: darkMode ? "grey" : "yellow" }}>☀︎</span> */}
      <span className="toggle">
        <input
          checked={darkMode}
          onChange={() => setDarkMode(prevMode => !prevMode)}
          id="checkbox"
          className="checkbox"
          type="checkbox"
        />
        <label htmlFor="checkbox" />
        {/* <span style={{ color: darkMode ? "slateblue" : "grey" }}>☾</span> */}
      </span>
      <LogoutIcon className="gpa__mode_icon" />
      {/* <button onClick={() => setDarkMode(prevMode => !prevMode)}>
      Toggle
    </button> */}
     </div>
    );
  }

  return (

    <BrowserRouter>
    <div className={darkMode ? "dark-mode" : "light-mode"}>
      <SwwipeableDrawer style={{ color: darkMode ? "slateblue" : "grey" }}/>
      <ToolBar>
          <Toggle/> 
      </ToolBar>
      

      <main >
        <Route path="/" exact component={ Home} />
        <Route path="/universities" exact component={ College } />
        
      </main>

      <Footer/>
    </div>
    </BrowserRouter>
  );
}

export default App;
