import React from 'react';
import './Footer.css';
import Row from 'react-bootstrap/Row';



const footer = props =>{
    return(
        
        <Row className="footer text-center gpa__footer_wrapper">

            <div className="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-xl-3">
                
                <div className=" widget_notice_board_widget widget-none" id="notice_board_widget-4">
                    <h4>Gpa NoticeBoard</h4>
                    <hr className="rule"/>
                      <p>Gpa elevator will be officially launched in January 2020 at makerere University main Hall and there after shall be left and maintained for use by all university student as asource of their academic materials.</p>
                  </div>
              
            </div>
            <div className="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-xl-3">
                <h4>Contact Us</h4>
                <hr className="rule"/>
                <ul className="contact_list">
                <li><i className="fas fa-phone-alt"></i>+256-759130054</li>
                <li><i className="fas fa-phone-alt"></i>+256-778451025</li>
                <li><i className="fas fa-location-arrow"></i><a href="https://www.mak.ac.ug/about-makerere/contact-information">Kampala,Uganda</a></li>
                <li><i className="fas fa-map-marked"></i><a href="https://www.mak.ac.ug/about-makerere/contact-information">Makerere University</a></li>
                <li><i className="fas fa-envelope-open"></i><a href="mailto:gpaelevator@gmail.com">gpaelevator@gmail.com</a></li>
              </ul>
            </div>

            <div className="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-xl-3">
              <h4>Follow Us</h4>
              <hr className="rule"/>
              <ul className="contact_list">
                  <li><i className="fab fa-facebook"></i><a href="/smedialink">Gpa Elevator</a></li>
                  <li><i className="fab fa-twitter"></i><a href="/smedialink">@gpaelevator</a></li>
                  <li><i className="fab fa-google-plus-g"></i><a href="/smedialink">Gpa Elevator</a></li>
                  <li><i className="fab fa-instagram"></i><a href="/smedialink">@gpaelevator</a></li>
                  <li><i className="fab fa-youtube"></i><a href="https://www.youtube.com/channel/UCaKoCKOuw4U2CfAEmxrlGGg " target="_blank">Gpa Elevator</a></li>
              </ul>
            </div>
            <div className="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-xl-3">
                <h4>About Us</h4>
                <hr className="rule"/>
                <ul className="contact_list">
                  <li><a href="/services">Our services</a></li>
                  <li><a href="developers_team.html">Developers Team</a></li>
                  <li><a href="/partners">Partners</a></li>
                  <li><a href="/volunteers">Volunteers</a></li>
                  <li><a href="/plans">Future plans</a></li>
                  <li><a href="/getting-started">How to use the Platform</a></li>
                </ul>
            </div>


           
        </Row>
    )
}
export default footer;