import React from 'react';
import './BackDrop.css';



const backdrop = props => (
    <div className="gpa__backdrop" onClick={props.click}>
        <button className="gpa__backdrop_icon">
            <span className="gpa__backdrop-close gpa__backdrop-close-left"/>
            <span className="gpa__backdrop-close gpa__backdrop-close-right"/>
        </button>
    </div>
);

export default backdrop;