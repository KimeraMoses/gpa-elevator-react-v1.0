import React from 'react';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
 
import img1 from '../../Assests/images/1.jpeg';
import img2 from '../../Assests/images/2.jpeg';
import img3 from '../../Assests/images/6.jpeg';
import './Slider.css'

const sliders = () => {
        return (

            <Carousel autoPlay infiniteLoop swipeable showThumbs={false} showArrows showIndicators showStatus={false} >
                <div Style={{height:"60vh"}}>
                    <img src={img1} alt=""/>
                    <p className="legend">Text Discription One</p>
                </div>
                <div>
                    <img src={img2} alt=""/>
                    <p className="legend">Text Discription One</p>
                </div>
                <div>
                    <img src={img3} alt=""/>
                    <p className="legend">Text Discription One</p>
                </div>
            </Carousel>

        );
 
};
 
export default sliders;
