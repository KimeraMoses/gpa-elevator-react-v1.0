import React from 'react';

import './DrawerToggleButton.css';

const drawerToggleButton = props => (
    <button className="gpa__toggle-button" onClick= {props.click}>
        <div className="gpa__toggle-button-line" />
        <div className="gpa__toggle-button-line" />
        <div className="gpa__toggle-button-line" />
    </button>
    
);


export default drawerToggleButton;