import React from 'react';

// import Logo from '../Logo/Logo';
import Membership from '../Membership/Membership';
import './SideDrawer.css';

const sideDrawer = props => {
    let drawerClasses = 'gpa__side-drawer';
    if (props.show){
        drawerClasses = 'gpa__side-drawer open'
    }
    return(
    <nav className={drawerClasses}>
        {/* <Logo/> */}
        <ul>
            <li><a href="/">Home</a></li>
        </ul>
        <Membership/>
    </nav>

);
}

export default sideDrawer;