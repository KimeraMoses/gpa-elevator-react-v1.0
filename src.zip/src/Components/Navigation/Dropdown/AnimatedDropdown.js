import React, { useState, useEffect, useRef } from 'react';
import { CSSTransition } from 'react-transition-group';

import { ReactComponent as UserlockIcon } from '../../../Assests/icons/user-lock.svg';
import { ReactComponent as UserIcon } from '../../../Assests/icons/user.svg';

import { ReactComponent as CogIcon } from '../../../Assests/icons/cog.svg';
import { ReactComponent as ChevronIcon } from '../../../Assests/icons/chevron.svg';
import { ReactComponent as PdfIcon } from '../../../Assests/icons/file-pdf.svg';
import { ReactComponent as ArrowIcon } from '../../../Assests/icons/arrow.svg';
import { ReactComponent as UsereditIcon } from '../../../Assests/icons/user-edit.svg';
import { ReactComponent as BoltIcon } from '../../../Assests/icons/bolt.svg';

import './AnimatedDropdown.css';

export default function DropdownMenu(props) {

    const DropItems = [
        {
            leftIcon: <UserIcon />,
            rightIcon: <UserIcon />,
            goToMenu:   'MUBS',
            FmenuItem: 'mubs'
        },
        {
            leftIcon: <UserIcon />,
            rightIcon: <UserIcon />,
            goToMenu:   'IUEA',
            FmenuItem: 'iuea'
        }
    ]
    
    const [activeMenu, setActiveMenu] = useState('main');
    const [menuHeight, setMenuHeight] = useState(null);
    const dropdownRef = useRef(null);
  
    useEffect(() => {
      setMenuHeight(dropdownRef.current?.firstChild.offsetHeight)
    }, [])
  
    function calcHeight(el) {
      const height = el.offsetHeight;
      setMenuHeight(height);
    }
  
    function DropdownItem(props) {
      return (
        <a href={'#' + props.goToMenu} className="menu-item" onClick={() => props.goToMenu && setActiveMenu(props.goToMenu)}>
          <span className="icon-button">{props.leftIcon}</span>
          {props.children}
          <span className="icon-right">{props.rightIcon}</span>
        </a>
      );
    }
  
    return (
      <div className="dropdown" style={{ height: menuHeight + 15 }} ref={dropdownRef}>
  
        <CSSTransition
          in={activeMenu === 'main'}
          timeout={500}
          classNames="menu-primary"
          unmountOnExit
          onEnter={calcHeight}>
          <div className="menu">
{/* 
          {DropItems.map((item, index) => {
            return(
                <DropdownItem key={index}

                leftIcon={item.leftIcon}
                rightIcon={item.rightIcon}
                goToMenu= {item.menuUrl}>
               {item.FmenuItem}
              </DropdownItem>
            )
      })} */}



          <DropdownItem
              leftIcon={<UserIcon />}
              rightIcon={<ChevronIcon />}
              goToMenu= 'muk'>
             Makerere
            </DropdownItem>
            <DropdownItem
              leftIcon={<CogIcon />}
              rightIcon={<ChevronIcon />}
              goToMenu="kyu">
              Kyambogo
            </DropdownItem>

  
          </div>
        </CSSTransition>

        <CSSTransition
          in={activeMenu === 'muk'}
          timeout={500}
          classNames="menu-secondary"
          unmountOnExit
          onEnter={calcHeight}>
          <div className="menu mobile-menu-has-dropdown">
            <DropdownItem goToMenu="main" leftIcon={<ArrowIcon />}>
              <strong className="gpa__mobile-menu-has-dropdown-title">MAKERERE UNIVERSITY</strong>
            </DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>CEDAT</DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>COCIS</DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>CAES</DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>CEES</DropdownItem>
          </div>
        </CSSTransition>
        <CSSTransition
          in={activeMenu === 'kyu'}
          timeout={500}
          classNames="menu-secondary"
          unmountOnExit
          onEnter={calcHeight}>
          <div className="menu mobile-menu-has-dropdown">
            <DropdownItem goToMenu="main" leftIcon={<ArrowIcon />}>
              <strong className="gpa__mobile-menu-has-dropdown-title">KYAMBOGO UNIVERSITY</strong>
            </DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>Faculty Of Engineering</DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>Faculty Of Science</DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>CAES</DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>CEES</DropdownItem>
          </div>
        </CSSTransition>
  
        <CSSTransition
          in={activeMenu === 'iuea'}
          timeout={500}
          classNames="menu-secondary"
          unmountOnExit
          onEnter={calcHeight}>
          <div className="menu mobile-menu-has-dropdown">
            <DropdownItem goToMenu="main" leftIcon={<ArrowIcon />}>
              <strong className="gpa__mobile-menu-has-dropdown-title">My Tutorial</strong>
            </DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>CMP1102</DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>CMP1103</DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>CMP1104</DropdownItem>
            <DropdownItem leftIcon={<BoltIcon />}>CMP1105</DropdownItem>
          </div>
        </CSSTransition>
        
  
        <CSSTransition
          in={activeMenu === 'mubs'}
          timeout={500}
          classNames="menu-secondary"
          unmountOnExit
          onEnter={calcHeight}>
          <div className="menu mobile-menu-has-dropdown">
            <DropdownItem goToMenu="main" leftIcon={<ArrowIcon />}>
              <strong className="gpa__mobile-menu-has-dropdown-title">My Account </strong >
            </DropdownItem>
            <DropdownItem leftIcon={<UsereditIcon />}>My profile</DropdownItem>
          <DropdownItem leftIcon={<UserlockIcon />}>Change Password</DropdownItem>
            <DropdownItem leftIcon={<PdfIcon />}>Past Papers</DropdownItem>
            <DropdownItem leftIcon={<PdfIcon />}>Lecture Notes</DropdownItem>
          </div>
        </CSSTransition>
      </div>
    );
  }