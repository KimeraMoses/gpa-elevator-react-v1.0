import React,{ useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';

import Dropdown from './Dropdown/AnimatedDropdown';

import  './Navigation.css';

import { ReactComponent as CaretDown } from '../../Assests/icons/caret-down.svg';
import { ReactComponent as CaretUp } from '../../Assests/icons/caret-up.svg';


const navigation =( props ) =>{

    return( 
            <ul className={styles.gpa__toolbar_navigation_item} >
                <NavigationItem Link="/">Home</NavigationItem>
                <NavigationItem  Link="/universities" right={<CaretDown/>} rightIcon={<CaretUp/>}  dropdown={<Dropdown FmenuItem= "Moxhus" menuUrl="moxhus"/>}>Universities
                    
                </NavigationItem>
                <NavigationItem Link="/about-us">About Us</NavigationItem>
                <NavigationItem Link="/contact-us">Contact Us</NavigationItem>
            </ul>
    );
}
 function NavigationItem (props) {
     
    const [open, setOpen] = useState(false);
    const onMouseEnter = () =>{
        setOpen(!open);
    }


    return(
      <li className="gpa__toolbar_navigation_item" >
        <Link className="gpa__main_nav_link" to={props.Link}  onClick={onMouseEnter}>{props.children}
            <span className="gpa__menu_icon_right">{ open ? props.rightIcon : props.right }</span>
      </Link>
        {open  && props.dropdown} 
      </li>
  );

   }

export default navigation;