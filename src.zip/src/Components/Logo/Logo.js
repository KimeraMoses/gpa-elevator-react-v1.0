import React from 'react';

import logo from '../../Assests/images/favorite.jpg'; // Tell webpack this JS file uses this image
import './Logo.css';

function Header(props) {
  
  return <img className="gpa__logo" src={logo} alt="Logo" />;
}

export default Header;