
import React from 'react';
// import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';
import DesktopWindowsIcon from '@material-ui/icons/DesktopWindows';
import SchoolIcon from '@material-ui/icons/School';
import AccountBalanceIcon from '@material-ui/icons/AccountBalance';

import Service from './Service';


const services = () => {
    return(
        // <Container>
            
        //     <Service/>      
        // </Container>
        <>
            <Row >
            <div className="col-md-12 gpa__service_section_title text-center">
                <h2>Everything you need to improve your grades</h2>
            </div> 
            </Row>
            <Row >
                {/* <div className="row col-12 "> */}
                
                    
                {/* </div> */}
            
                <Service 
                    icon={ <CloudDownloadIcon/>} 
                    title='Free study resources' 
                    discription='Download free study resources like past papers, lecture notes, assignments, solutions and much more!' 
                />
                <Service 
                    icon={ <AccountBalanceIcon/>} 
                    title='Upgrade Your Skills' 
                    discription='Get access to all content of your course from all universities offering it in Uganda well organized to help you understand it better.'    
                />
            
                <Service 
                    icon={ <DesktopWindowsIcon/>} 
                    title='Study anytime, anywhere, on any device' 
                    discription='We very well know that being a university student, many things might not go as planned and you may need to study whenever and wherever you may be. Gpa Elevator is the best partner for you.'
                    
                />
                <Service 
                    icon={ <SchoolIcon/>} 
                    title="Be Part Of One's Success" 
                    discription="Here we believe that nothing can make someone happy like succeeding with a fellow friend and that's why we make it possible for every one to contribute to anothers' success"   
                />

         
            </Row>
            </>
        
    );
}
export default services;