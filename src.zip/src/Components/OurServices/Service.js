import React from 'react';
import './Ourservices.css';




const service = (props) => {
    return( 


        <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 gpa__service_section_wrapper">
            <div className="gpa__service_section">

              <div className="gpa__service_section_inner">

                <div className="gpa__service_section_icon_wrapper">
                  <span className="gpa__service_section_icon">{props.icon}</span>
                </div>

                <h3 className="gpa__service_title"><b> {props.title}</b></h3>
                <p className="gpa__service_discription">{props.discription}</p>
   
              </div>
            </div>
        </div>

    );
}
export default service;