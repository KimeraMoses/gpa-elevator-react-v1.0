import React from 'react'
import mukLogo from '../../Assests/images/muk-logo.png';
import './SideBar.css';

import { Link } from 'react-router-dom';

const rightSideBar =(props) => {

        const isMustCheck = true;

        const MustCheck = (props) =>{
            
            return(
            <div className="gpa__must_checkout">

                <div className="col-12"><h3>MUST CHECKOUTS</h3></div>
                <div className="row side-menu">

                    <div className="gpa__sidebar_nav_item menu-item-01 col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
                        <Link to="/" target="_blank" > Time Tables</Link>
                    </div>
                    <div className="gpa__sidebar_nav_item menu-item-02 col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
                        <Link to="/universities" target="_blank">Notice Board</Link>
                    </div>
                    <div className="gpa__sidebar_nav_item menu-item-03  col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" >
                        <Link to="/" target="_blank">Blog</Link>
                    </div>
                </div> 
            
            </div>
            );
        }

        return(
            <>
                  
                <div  id="gpa__college_sidebar" className="gpa__right_sidebar_wrapper">

                    { isMustCheck ? <MustCheck /> : null}

                    <div className="gpa__sidebar_website_guide">
                        <strong><h4 className="gpa__college_sidabar_guide_title">Quick Guide | Gpa Elevator</h4></strong>
                        <div id="gpa__college_sidebar_guidelines_wrapper">
                        <p>Just click on your course, then select the year which you want to visit and then select that particular course unit to get access to all papers and lecture notes<br/>
                                OR<br/>
                            Search for that Particular course units using course-unit name or course code to get you there directly..
                        </p>  
                        
                        </div>
                    </div>
                    
                    <div className="gpa__college_sidebar_university_links_wrapper text-center">
                        <img id="gpa__college_sidebar_university_logo" src={ mukLogo }  alt="logo"/> <span>
                            <strong><h3 className="gpa__sidebar_quick_links">Quick Links</h3></strong></span>
                        <div className="gpa__sidebar_quick_links_wrapper">
                            <ul className="gpa__quick_links_ul">
                                <li className="gpa__college_sidebar_quick_link" id="link-item-first-child"><Link to="/">Home Page</Link></li>
                                <li className="gpa__college_sidebar_quick_link"><Link to="/" target="_blank">University Website</Link></li>
                                <li className="gpa__college_sidebar_quick_link"><Link to="/" target="_blank">Students Portal</Link></li>
                                <li className="gpa__college_sidebar_quick_link"><Link to="/" target="_blank">e-Learning</Link></li>
                                <li className="gpa__college_sidebar_quick_link"><Link to="/" target="_blank">Admissions Portal</Link></li>
                                <li className="gpa__college_sidebar_quick_link"><Link to="/" target="_blank">Scholarships</Link></li>            
                            </ul>
                        </div>
                    </div>

                </div>

            </>
        );
}

export default rightSideBar;

