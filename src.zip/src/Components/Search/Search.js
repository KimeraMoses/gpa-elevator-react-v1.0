import React from 'react';

import { ReactComponent as SearchIcon } from '../../Assests/icons/search.svg';
import styles from './Search.module.css';

const search = props => (
   <div className={styles.gpa__search_section}>
       <form className={styles.gpa__search_form}>
           <input type="text" placeholder='Type university,course,course unit....'/>
            {<SearchIcon className={styles.gpa__search_icon}/>}
       </form>
   </div>
);

export default search;