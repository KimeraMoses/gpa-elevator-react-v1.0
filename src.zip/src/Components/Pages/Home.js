import React from 'react'

import Slider from '../Slider/Slider';
import Services from '../OurServices/OurServices';


const home =()=>{
    return(
        <>
        <Slider/>
      
        <Services/>

        </>
    );
}

export default home;