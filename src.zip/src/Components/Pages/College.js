import React from 'react'
import Row from 'react-bootstrap/Row'


import RightSideBar from '../SideBar/SideBar';
import School from '../../Containers/University/School/School';

const home =()=>{
    return(
        <Row>
            <div className="col-md-8">
                <School/>
            </div>
            <div className="col-md-4">
                <RightSideBar/>
            </div>
            

        </Row>
    );
}

export default home;