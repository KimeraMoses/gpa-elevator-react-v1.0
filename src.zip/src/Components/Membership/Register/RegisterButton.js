import React from 'react';
import { Link } from 'react-router-dom';

import multnames from 'classnames';
import styles from './Register.module.css';
import style from '../Membership.module.css';

const register = props =>(
        <Link className={multnames(style.gpa__membership ,styles.gpa__register)} to="/register" >Register</Link>
);


export default register;