import React from 'react';
import { Link } from 'react-router-dom';

import multnames from 'classnames';
import styles from './Login.module.css';
import style from '../Membership.module.css';


const loginButton = props =>(
        <Link className={ multnames(style.gpa__membership , styles.gpa__login)} to="/login" >Login</Link>
);


export default loginButton;