import './UserSettings.css';
import { ReactComponent as UserlockIcon } from '../../../Assests/icons/user-lock.svg';
import { ReactComponent as UserIcon } from '../../../Assests/icons/user.svg';

import { ReactComponent as LogoutIcon } from '../../../Assests/icons/arrow-right.svg';
import { ReactComponent as CogIcon } from '../../../Assests/icons/cog.svg';
import { ReactComponent as ChevronIcon } from '../../../Assests/icons/chevron.svg';
import { ReactComponent as PdfIcon } from '../../../Assests/icons/file-pdf.svg';
import { ReactComponent as ArrowIcon } from '../../../Assests/icons/arrow.svg';
import { ReactComponent as UsereditIcon } from '../../../Assests/icons/user-edit.svg';
import { ReactComponent as BoltIcon } from '../../../Assests/icons/bolt.svg';
import { ReactComponent as CaretDown } from '../../../Assests/icons/caret-down.svg';
import { ReactComponent as CaretUp } from '../../../Assests/icons/caret-up.svg';

import React, { useState, useEffect, useRef } from 'react';
import { CSSTransition } from 'react-transition-group';

function userSettings(props) {
  
  return (
    <Navbar>

      <NavItem icon={<UserIcon />} right={<CaretDown/>} rightIcon={<CaretUp/>} userName="Moxhus">
        <DropdownMenu></DropdownMenu>
        
      </NavItem>
    </Navbar>
  );
}

function Navbar(props) {
  return (
    <nav className="navbar">
      <ul className="navbar-nav">{props.children}</ul>
    </nav>
  );
}

function NavItem(props) {
  const [open, setOpen] = useState(false);

  return (
    <div className="container gpa__usersetting_wrapper">
    <li className="nav-item">

      <a  href="#" className="icon-button" onMouseEnter={() => setOpen(!open)} >
        <span className="gpa__userName">{props.userName}</span>
      {props.icon}
        <span className="icon-right icon-rightr">{ open ? props.rightIcon : props.right }</span>

      </a> 

      {open && props.children} 
      
    </li> 
    </div>
  ); 
}

export function DropdownMenu() {
  const [activeMenu, setActiveMenu] = useState('main');
  const [menuHeight, setMenuHeight] = useState(null);
  const dropdownRef = useRef(null);

  useEffect(() => {
    setMenuHeight(dropdownRef.current?.firstChild.offsetHeight)
  }, [])

  function calcHeight(el) {
    const height = el.offsetHeight;
    setMenuHeight(height);
  }

  function DropdownItem(props) {
    return (
      <a href="#" className="menu-item" onClick={() => props.goToMenu && setActiveMenu(props.goToMenu)}>
        <span className="icon-button">{props.leftIcon}</span>
        {props.children}
        <span className="icon-right">{props.rightIcon}</span>
      </a>
    );
  }

  return (
    <div className="dropdown" style={{ height: menuHeight + 15 }} ref={dropdownRef}>

      <CSSTransition
        in={activeMenu === 'main'}
        timeout={500}
        classNames="menu-primary"
        unmountOnExit
        onEnter={calcHeight}>
        <div className="menu">
        <DropdownItem
            leftIcon={<UserIcon />}
            rightIcon={<ChevronIcon />}
            goToMenu="My-Account">
            My Account
          </DropdownItem>
          <DropdownItem
            leftIcon={<CogIcon />}
            rightIcon={<ChevronIcon />}
            goToMenu="settings">
            Settings
          </DropdownItem>
          <DropdownItem
            leftIcon={<LogoutIcon/>}>
            Logout
          </DropdownItem>

        </div>
      </CSSTransition>

      <CSSTransition
        in={activeMenu === 'settings'}
        timeout={500}
        classNames="menu-secondary"
        unmountOnExit
        onEnter={calcHeight}>
        <div className="menu mobile-menu-has-dropdown">
          <DropdownItem goToMenu="main" leftIcon={<ArrowIcon />}>
            <strong className="gpa__mobile-menu-has-dropdown-title">My Tutorial</strong>
          </DropdownItem>
          <DropdownItem leftIcon={<BoltIcon />}>CMP1102</DropdownItem>
          <DropdownItem leftIcon={<BoltIcon />}>CMP1103</DropdownItem>
          <DropdownItem leftIcon={<BoltIcon />}>CMP1104</DropdownItem>
          <DropdownItem leftIcon={<BoltIcon />}>CMP1105</DropdownItem>
        </div>
      </CSSTransition>

      <CSSTransition
        in={activeMenu === 'My-Account'}
        timeout={500}
        classNames="menu-secondary"
        unmountOnExit
        onEnter={calcHeight}>
        <div className="menu mobile-menu-has-dropdown">
          <DropdownItem goToMenu="main" leftIcon={<ArrowIcon />}>
            <strong className="gpa__mobile-menu-has-dropdown-title">My Account </strong >
          </DropdownItem>
          <DropdownItem leftIcon={<UsereditIcon />}>My profile</DropdownItem>
        <DropdownItem leftIcon={<UserlockIcon />}>Change Password</DropdownItem>
          <DropdownItem leftIcon={<PdfIcon />}>Past Papers</DropdownItem>
          <DropdownItem leftIcon={<PdfIcon />}>Lecture Notes</DropdownItem>
        </div>
      </CSSTransition>
    </div>
  );
}

export default userSettings;
