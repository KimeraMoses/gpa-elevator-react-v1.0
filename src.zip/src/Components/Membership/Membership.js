import React from 'react';

import LoginButton from './Login/LoginButton';
import RegisterButton from './Register/RegisterButton';
import UserSettings from './UserSettings/UserSettings';
import styles from './Membership.module.css'


const isLoggedIn = false;

const membership = prop => (
    <div className={styles.gpa__membership_section}>
     { isLoggedIn ? <UserSettings /> : 
    <>  
    <LoginButton />
    <RegisterButton />
    </>
     }
    </div>
);


export default membership;